<?php
$office_work =  
	array(
		'1' => array('pay'=> '1100'), 
		'2' => array('pay'=> '1500'), 
		'3' => array('pay'=> '1800'), 
		'4' => array('pay'=> '2200'), 
		
		);
	
	
	
	?>