<?php session_start();
header('Content-type: text/html; charset=utf-8');
$studentid=$_SESSION['studentid'];
?>

<!DOCTYPE HTML>
<html>
<head>
<title>CUET Registration System </title>
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
</head>
<body>
<div class="header">	
	<div class="header-top">
		<div class="wrap">
				<div class="logo">
					
				</div>
				<div class="search_box">
				
			</div>
			<div class="clear"></div> 
	    </div>
    </div>
	<div class="header-bottom">
		 <div class="wrap"> 
			 <div id='cssmenu'>
				<ul>
				   <li><a href='index.html'><span>Home</span></a></li>
				   <li><a href='about.html'><span>About</span></a></li>
				 <li><a href='dash.php'><span>Register</span></a></li>
				 <li><a href='status.php'><span>Status</span></a></li>
				 <li><a href='logout.php'><span>Logout</span></a></li>
				   <div class="clear"></div> 
				</ul>
			  </div>
			  
		 </div>
    </div>	
</div>
     <div class="content-top">
			<div class="wrap">
				 
				<div class="section group">
				 <div class="col span_2_of_contact">
				  <center>
				  
				  <link rel="stylesheet" href="menus.css" type="text/css" />
				  
				 <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.4/jquery.min.js"></script>
<script type="text/javascript">
 $(function() {
		/* For zebra striping */
        $("table tr:nth-child(odd)").addClass("odd-row");
		/* For cell text alignment */
		$("table td:first-child, table th:first-child").addClass("first");
		/* For removing the last border */
		$("table td:last-child, table th:last-child").addClass("last");
});
</script>

<style type="text/css">

	html, body, div, span, object, iframe,
	h1, h2, h3, h4, h5, h6, p, blockquote, pre,
	abbr, address, cite, code,
	del, dfn, em, img, ins, kbd, q, samp,
	small, strong, sub, sup, var,
	b, i,
	dl, dt, dd, ol, ul, li,
	fieldset, form, label, legend,
	table, caption, tbody, tfoot, thead, tr, th, td {
		margin:0;
		padding:0;
		border:0;
		outline:0;
		
		font-size:100%;
		vertical-align:baseline;
		background:transparent;
	}
	
	body {
		margin:0;
		padding:0;
		font:12px/15px "Helvetica Neue",Arial, Helvetica, sans-serif;
		color: #555;
		background:#f5f5f5 url(bg.jpg);
	}
	
	a {color:#666;}
	
	#content {width:100%; max-width:690px; margin:6% auto 0;float:left;padding-left:100px;}
	
	/*
	Pretty Table Styling
	CSS Tricks also has a nice writeup: http://css-tricks.com/feature-table-design/
	*/
	
	table {
		overflow:hidden;
		border:1px solid #d3d3d3;
		background:#fefefe;
		width:70%;
		margin:5% auto 0;
		-moz-border-radius:5px; /* FF1+ */
		-webkit-border-radius:5px; /* Saf3-4 */
		border-radius:5px;
		-moz-box-shadow: 0 0 4px rgba(0, 0, 0, 0.2);
		-webkit-box-shadow: 0 0 4px rgba(0, 0, 0, 0.2);
	}
	
	th, td {padding:18px 28px 18px; text-align:center; }
	
	th {padding-top:22px; text-shadow: 1px 1px 1px #fff; background:#e8eaeb;}
	
	td {border-top:1px solid #e0e0e0; border-right:1px solid #e0e0e0;}
	
	tr.odd-row td {background:#f6f6f6;}
	
	td.first, th.first {text-align:left}
	
	td.last {border-right:none;}
	
	/*
	Background gradients are completely unnecessary but a neat effect.
	*/
	
	td {
		background: -moz-linear-gradient(100% 25% 90deg, #fefefe, #f9f9f9);
		background: -webkit-gradient(linear, 0% 0%, 0% 25%, from(#f9f9f9), to(#fefefe));
	}
	
	tr.odd-row td {
		background: -moz-linear-gradient(100% 25% 90deg, #f6f6f6, #f1f1f1);
		background: -webkit-gradient(linear, 0% 0%, 0% 25%, from(#f1f1f1), to(#f6f6f6));
	}
	
	th {
		background: -moz-linear-gradient(100% 20% 90deg, #e8eaeb, #ededed);
		background: -webkit-gradient(linear, 0% 0%, 0% 20%, from(#4C6F07), to(#E4F6BA));
	}
	
	/*
	I know this is annoying, but we need additional styling so webkit will recognize rounded corners on background elements.
	Nice write up of this issue: http://www.onenaught.com/posts/266/css-inner-elements-breaking-border-radius
	
	And, since we've applied the background colors to td/th element because of IE, Gecko browsers also need it.
	*/
	
	tr:first-child th.first {
		-moz-border-radius-topleft:5px;
		-webkit-border-top-left-radius:5px; /* Saf3-4 */
	}
	
	tr:first-child th.last {
		-moz-border-radius-topright:5px;
		-webkit-border-top-right-radius:5px; /* Saf3-4 */
	}
	
	tr:last-child td.first {
		-moz-border-radius-bottomleft:5px;
		-webkit-border-bottom-left-radius:5px; /* Saf3-4 */
	}
	
	tr:last-child td.last {
		-moz-border-radius-bottomright:5px;
		-webkit-border-bottom-right-radius:5px; /* Saf3-4 */
	}

</style>


<center>
<img src='http://upload.wikimedia.org/wikipedia/bn/e/e8/BKash_logo.png'>

<h3>
<?php include"con.php";

   
     echo "Student ID :".$studentid;
    $result = mysqli_query($con,"SELECT * FROM reg where studentid='$studentid'");

while($row = mysqli_fetch_array($result)) {
echo"<br>";
echo "Students  Name :".$row['studentname'];
echo"<br>";
echo "Fathers Name :".$row['fname'];
echo"<br>";
echo "Mothers Name :".$row['mname'];
echo"<br>";
echo "Level :".$row['level'];
echo"&nbsp;&nbsp;&nbsp;&nbsp;";
echo "Term :".$row['term'];
echo"<br>";


}



?>
</h3>

<h3 style='color:red;font-size:25px'><b> Make Payment to +8801711011011 </b></h3> 
<h3 style='color:green;font-size:22px'><b> Amount <?php echo $_GET['total'];  ?> BDT </b></h3>





</center>


<br>

<img src='http://10.175.165.11/SP69.13.47.54/SDbluecart.com.bd/Spmedia%2fwysiwyg%2fbkash-send-money/Rqae5eb53b-c103-49e4-a363-9cb05f81161d/ID20D393AD49B88EEA/RV200000/AVSkyController_3.0.3.45966/Br200/CL2-global/EI2873925388/Ht240/IP10.32.121.68%3a51336/IQ25/MO15/MT0/NIGPMOCCA-GAZDIST1-SKFCTL1/OC0/OS47004/Otjpeg/PB200/PNMedCongestion_2G_Desktop/SI0700060088c850000000000000000000000000000a207944000000000000000000000000450d2f3628871e16a5be7f00/SUhttp%3a%2f%2fbluecart.com.bd%2fmedia%2fwysiwyg%2fbkash-send-money.jpg/Sd736B7966697265/TI2873925388/Tr1/Wh400/EV012c17d285f92dae2f20bdf1e9488925/file.jpeg'>
<p style='color:black;font-size:15px'><b> N.B : 3.Enter the number given as Reciever wallet number.<br><br> 4.Must enter the amount specified,neither more nor less. <br><br>5.Enter your Stduent ID as Reference.<br><br>After Successful Tarnsaction a SMS would be recieved.<br><br>Enter the Transaction Id (TrxID) mentioned below.(Example:'1419875104') <br><br>Helpline:8801674092684 </b></p>

<form action='paymentdone.php' method='post' >
<input style="width:200px;border-radius: 4px;" name="tnx" type="text" placeholder="Transection ID (TrxID) ">
<input style="display:none;width:200px;border-radius: 4px;" name="tnx" type="text" value="<?php echo $studentid; ?>">
<input style="display:none;width:200px;border-radius: 4px;" name="tnx" type="text" value="<?php echo $_GET['total']; ?> ">
<input type="submit" style="color: white;width:200px;height:30px; background-color: #7845BA; border-radius: 4px;"  value="Verify Transection">

</form>
<?php
$studentid=$_GET['id'];
$total=$_GET['total'];
$tc=$_GET['tc'];
//var_dump($_GET);
				  
				  
	?>			  
				  
				  
					    </center>
				 
  				</div>
				<div class="col span_1_of_contact">
				  <div class="company_address">
				     	
				   	
				   </div>
				 </div>
				 <div class="clear"></div>
			  </div>
			</div>
	</div>
<div class="footer-bottom">
 	<div class="wrap">
 		<div class="copy">
			<p> © 2014 All rights Reserved | Design by Armaan 0904093</a></p>
		</div>
 	</div>
 </div>
</body>
</html>

    	
    	
            