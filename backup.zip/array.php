$f_log =  
	array(
		
		'l4t1' => array('finee'=> 109 ,'fee' =>1500, ), 
		'l4t2' => array('finee'=> 0 , 'fee' =>1800,),
		
		
	);