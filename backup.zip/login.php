<?php session_start();
require_once("con.php");

$studentid=$_POST['studentid'];
$password=$_POST['password'];
$pa=md5('cuetZXCV');
$password2=md5($password);
if($studentid=='Admin'&&$password2==$pa){$_SESSION['admin']='admin'; header('location:admin.php'); die();}
    $result = mysqli_query($con,"SELECT * FROM student WHERE studentid='$studentid' AND password='$password2'");


$c=mysqli_num_rows($result);
if($c>0){ $_SESSION['studentid']=$studentid; header('location:dash.php'); }
else { header('location:index.php?action=no'); }


?>