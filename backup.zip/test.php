<?php 
$p=md5('abc123');
echo $p;

echo "&nbspe99a18c428cb38d5f260853678922e";

?>